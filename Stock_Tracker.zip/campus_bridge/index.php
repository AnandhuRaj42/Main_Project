<?php
header("Location: login/log.php");
exit;
?>
